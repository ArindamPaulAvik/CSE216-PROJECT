const express = require('express');
const pool = require('./db'); // Your MySQL pool setup
const app = express();
const port = 5000;

const cors = require('cors');
app.use(cors());




// Middleware to parse JSON bodies
app.use(express.json());

const bcrypt = require('bcrypt');

// POST /login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ error: 'Email and password are required' });

  try {
    // 1. Find the person by email
    const [users] = await pool.execute(
      'SELECT PERSON_ID, EMAIL, PASSWORD_HASHED FROM PERSON WHERE EMAIL = ?',
      [email]
    );

    if (users.length === 0)
      return res.status(401).json({ error: 'Invalid email or password' });

    const user = users[0];

    // 2. Compare the hashed password
    const match = await bcrypt.compare(password, user.PASSWORD_HASHED);

    if (!match)
      return res.status(401).json({ error: 'Invalid email or password' });

    // 3. Return success and person ID (or session/JWT if needed)
    res.status(200).json({
      message: 'Login successful',
      personId: user.PERSON_ID
      // optionally: issue JWT here
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const saltRounds = 10;

app.post('/register', async (req, res) => {
  const { email, password, userFirstname, userLastname, countryId } = req.body;

  if (!email || !password || !userFirstname || !userLastname || !countryId) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    // Check if email already exists
    const [existing] = await pool.query('SELECT PERSON_ID FROM PERSON WHERE EMAIL = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Insert into PERSON table
    const [personResult] = await pool.query(
      'INSERT INTO PERSON (EMAIL, PASSWORD_HASHED) VALUES (?, ?)',
      [email, hashedPassword]
    );

    const personId = personResult.insertId;

    // Insert into USER table (depends on PERSON ID)
    await pool.query(
      `INSERT INTO USER (PERSON_ID, COUNTRY_ID, USER_FIRSTNAME, USER_LASTNAME)
       VALUES (?, ?, ?, ?)`,
      [personId, countryId, userFirstname, userLastname]
    );

    res.status(201).json({ message: 'User registered successfully' });

  } catch (err) {
    console.error('Error registering user:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET all shows with joins (optional)
app.get('/shows', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        s.SHOW_ID, s.TITLE, s.THUMBNAIL, s.DESCRIPTION, s.RATING, 
        s.RELEASE_DATE, s.DURATION, s.SEASON_COUNT,
        c.CATEGORY_NAME,
        p.PUBLISHER_NAME,
        a.AGE_RESTRICTION_NAME
      FROM \`show\` s
      LEFT JOIN CATEGORY c ON s.CATEGORY_ID = c.CATEGORY_ID
      LEFT JOIN PUBLISHER p ON s.PUBLISHER_ID = p.PUBLISHER_ID
      LEFT JOIN AGE_RESTRICTION a ON s.AGE_RESTRICTION_ID = a.AGE_RESTRICTION_ID;
    `);

    res.json(rows);
  } catch (err) {
    console.error('Error fetching shows:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// Root route
app.get('/', (req, res) => {
  res.send('Welcome to the backend API!');
});

//iso8601 
// Front page route - serves basic HTML
app.get('/frontpage', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Front Page</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          padding: 40px;
          text-align: center;
          background-color:rgb(126, 7, 7);
        }
        h1 {
          color: #333;
          font-size: 2.5rem;
        }
      </style>
    </head>
    <body>
      <h1>Show's Name</h1>
    </body>
    </html>
  `);
});

// GET all users
app.get('/admin_users', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM USER');

    // Format BIRTH_DATE to YYYY-MM-DD for each row
    const formattedRows = rows.map(user => {
      if (user.BIRTH_DATE instanceof Date) {
        const d = user.BIRTH_DATE;
        const year = d.getUTCFullYear();
        const month = String(d.getUTCMonth() + 1).padStart(2, '0');
        const day = String(d.getUTCDate()).padStart(2, '0');
        user.BIRTH_DATE = `${year}-${month}-${day}`;
      }
      return user;
    });

    res.json(formattedRows);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// POST a new user with proper BIRTH_DATE handling
app.post('/users', async (req, res) => {
  let {
    PERSON_ID,
    COUNTRY_ID,
    USER_FIRSTNAME,
    USER_LASTNAME,
    PHONE_NO,
    BIRTH_DATE
  } = req.body;

  try {
    if (BIRTH_DATE) {
      const d = new Date(BIRTH_DATE);
      if (isNaN(d)) {
        return res.status(400).json({ error: 'Invalid birth date format' });
      }

      const year = d.getUTCFullYear();
      const month = String(d.getUTCMonth() + 1).padStart(2, '0');
      const day = String(d.getUTCDate()).padStart(2, '0');

      BIRTH_DATE = `${year}-${month}-${day}`;
    }

    console.log('Inserting BIRTH_DATE:', BIRTH_DATE);

    const sql = `
      INSERT INTO USER (PERSON_ID, COUNTRY_ID, USER_FIRSTNAME, USER_LASTNAME, PHONE_NO, BIRTH_DATE)
      VALUES (?, ?, ?, ?, ?, ?)
    `;

    const [result] = await pool.execute(sql, [
      PERSON_ID,
      COUNTRY_ID,
      USER_FIRSTNAME,
      USER_LASTNAME,
      PHONE_NO,
      BIRTH_DATE
    ]);

    res.status(201).json({ message: 'User created', userId: result.insertId });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Start server
app.listen(port, () => {
  console.log(`✅ Server running at http://localhost:${port}`);
});
 